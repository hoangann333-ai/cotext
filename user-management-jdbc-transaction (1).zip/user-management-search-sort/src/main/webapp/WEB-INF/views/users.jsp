<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Quản lý người dùng</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body>
<main class="container">
    <header class="page-header">
        <div><p class="eyebrow">USER MANAGEMENT</p><h1>Danh sách người dùng</h1>
            <p class="subtitle">Tìm theo quốc gia và sắp xếp theo tên.</p></div>
    </header>
    <c:if test="${success}"><div class="alert success">Đã thêm User và gán quyền thành công.</div></c:if>
    <p class="create-link"><a href="${pageContext.request.contextPath}/users?action=create">＋ Thêm người dùng</a></p>
    <form class="filters" method="get" action="${pageContext.request.contextPath}/users">
        <label for="country">Quốc gia</label>
        <input id="country" name="country" type="search" value="<c:out value='${country}'/>" placeholder="Ví dụ: Vietnam">
        <label for="sort">Sắp xếp tên</label>
        <select id="sort" name="sort">
            <option value="ASC" ${sort == 'ASC' ? 'selected' : ''}>A → Z</option>
            <option value="DESC" ${sort == 'DESC' ? 'selected' : ''}>Z → A</option>
        </select>
        <button type="submit">Áp dụng</button>
        <a class="reset" href="${pageContext.request.contextPath}/users">Xóa lọc</a>
    </form>
    <section class="table-card">
        <div class="table-heading"><h2>Người dùng</h2><span><c:out value="${fn:length(users)}"/> kết quả</span></div>
        <div class="table-scroll"><table>
            <thead><tr><th>ID</th><th>Họ tên</th><th>Email</th><th>Quốc gia</th></tr></thead>
            <tbody>
            <c:choose>
                <c:when test="${empty users}"><tr><td colspan="4" class="empty">Không tìm thấy người dùng phù hợp.</td></tr></c:when>
                <c:otherwise><c:forEach var="user" items="${users}">
                    <tr><td><c:out value="${user.id}"/></td><td class="name"><c:out value="${user.name}"/></td>
                        <td><c:out value="${user.email}"/></td><td><span class="country"><c:out value="${user.country}"/></span></td></tr>
                </c:forEach></c:otherwise>
            </c:choose>
            </tbody>
        </table></div>
    </section>
    <p class="note">Tìm kiếm dùng LIKE theo quốc gia; sắp xếp dùng ORDER BY name.</p>
</main>
</body>
</html>
