package com.codegym.dao;

import com.codegym.model.Employee;
import com.codegym.model.User;
import java.sql.SQLException;
import java.util.List;

public interface IUserDAO {
    List<User> findUsers(String country, String sortDirection) throws SQLException;
    void addUserTransaction(User user, int[] permissionIds) throws SQLException;
    void insertUpdateUseTransaction() throws SQLException;
    void insertUpdateUseTransaction(boolean simulateFailure) throws SQLException;
    List<Employee> findEmployees() throws SQLException;
}
