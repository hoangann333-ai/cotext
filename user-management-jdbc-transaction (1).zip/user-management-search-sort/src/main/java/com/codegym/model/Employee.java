package com.codegym.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Employee {
    private final int id;
    private final String name;
    private final BigDecimal salary;
    private final Timestamp createdAt;

    public Employee(int id, String name, BigDecimal salary, Timestamp createdAt) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.createdAt = createdAt;
    }
    public int getId() { return id; }
    public String getName() { return name; }
    public BigDecimal getSalary() { return salary; }
    public Timestamp getCreatedAt() { return createdAt; }
}
